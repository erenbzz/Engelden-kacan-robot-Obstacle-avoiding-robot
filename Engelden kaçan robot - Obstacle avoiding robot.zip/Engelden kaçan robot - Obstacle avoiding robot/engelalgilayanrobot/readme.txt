Çalışma prensibi: 

 İlk başta HC-SR04 mesafe sensörlerinden gelen bilgiyi Arduino mikroişlemci ile okuyoruz ve daha sonra her sensörlerden gelen bilgiye göre motorlara hareket bilgisini yazdırıyoruz. Mesala soldaki sensör bir engel algıladıysa sağa dönme, sağdaki sensör bir engel algıladıysa sola dönme hareketini motorlara yazdırıyoruz. Eğer herhangi bir sensör engel algılamadıysa araç ileri hareketini sağlıyor. Burada motorların kontrollerini sağlamak için L293B motor sürücü entegresini kullanıyoruz. DHT11 sensörünü ise HC-SR04 mesafe sensörünün doğru çalışması için kullanıyoruz. Sıcaklık bilgisine göre mesafe sensörünü kalibre ediyoruz.

 Projede Kullanılan Ana Malzemeler:
• 1 adet Arduino Nano mikroişlemci.
• 3 adet HC-SR04 ultrasonik mesafe sensörü.
• 1 adet DHT11 Sıcaklık sensörü.
• 1 adet L293B motor sürücü entegre.
• 2 adet DC motor ve tekerlek.

